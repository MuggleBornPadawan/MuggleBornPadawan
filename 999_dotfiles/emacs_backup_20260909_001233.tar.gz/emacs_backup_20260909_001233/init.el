;; -*- lexical-binding: t -*-

;; ==========================================
;; 1. STARTUP OPTIMIZATIONS & PERFORMANCE
;; ==========================================

;; Temporarily increase GC limit during startup to speed up loading
(setq gc-cons-threshold 100000000) ; 100 MB
(setq read-process-output-max 1048576) ; 1 MB

;; Restore sensible GC threshold after initialization is complete
(add-hook 'emacs-startup-hook
          (lambda ()
            (setq gc-cons-threshold 800000))) ; 800 KB

;; ==========================================
;; 2. ENVIRONMENT & GENERAL SETTINGS
;; ==========================================

(setq inhibit-startup-screen t)
(setq initial-scratch-message nil)
(setq ring-bell-function 'ignore)
(setq-default frame-title-format "%b (%f)")

;; Auto-save and backups
(setq backup-directory-alist `(("." . ,(concat user-emacs-directory "backups"))))
(setq auto-save-default nil)

;; History and state saving
(desktop-save-mode 1)
(recentf-mode 1)
(savehist-mode 1)
(save-place-mode 1)
(setq history-length 25)
(setq recentf-max-menu-items 40)
(setq recentf-save-file (concat user-emacs-directory ".recentf"))

;; Buffer auto-revert
(global-auto-revert-mode 1)
(setq global-auto-revert-non-file-buffers t)

;; Startup window arrangement
(split-window-horizontally)
(list-buffers)

;; ==========================================
;; 3. CUSTOM CONFIGURATION FILE
;; ==========================================

;; Keep init.el clean by sending auto-generated customize variables to custom.el
(setq custom-file (expand-file-name "custom.el" user-emacs-directory))
(when (file-exists-p custom-file)
  (load custom-file))

;; ==========================================
;; 4. PACKAGE MANAGEMENT
;; ==========================================

(require 'package)
(add-to-list 'package-archives '("gnu" . "https://elpa.gnu.org/packages/") t)
(add-to-list 'package-archives '("melpa" . "https://melpa.org/packages/") t)
(add-to-list 'package-pinned-packages '(cider . "melpa-stable") t)
(add-to-list 'package-pinned-packages '(magit . "melpa-stable") t)

(package-initialize)

;; Bootstrap use-package
(unless (package-installed-p 'use-package)
  (package-refresh-contents)
  (package-install 'use-package))
(require 'use-package)
(setq use-package-always-ensure t)

;; ==========================================
;; 5. SYSTEM ENVIRONMENT INTEGRATION
;; ==========================================

(use-package exec-path-from-shell
  :ensure t
  :config
  (exec-path-from-shell-initialize))

;; Load external custom config modules
(add-to-list 'load-path (expand-file-name "customizations" user-emacs-directory))

(load "shell-integration.el" t)
;; (load "navigation.el" t) ; Commented out in original configuration
;; (load "ui.el" t)         ; Commented out in original configuration
(load "editing.el" t)
(load "misc.el" t)
(load "elisp-editing.el" t)
(load "setup-clojure.el" t)
(load "setup-js.el" t)

;; ==========================================
;; 6. UI & DISPLAY SETTINGS
;; ==========================================

(menu-bar-mode -1)
(tool-bar-mode -1)
(scroll-bar-mode -1)
(blink-cursor-mode 0)

;; Typography
(set-face-attribute 'default nil :family "DejaVu Sans Mono" :height 120)
(set-face-attribute 'fixed-pitch nil :family "DejaVu Sans Mono" :height 120)

;; Line wrapping & numbers (from original's final settings)
(setq-default truncate-lines nil)
(global-display-line-numbers-mode 0)
(global-visual-line-mode 1)
(setq visual-line-fringe-indicators '(nil nil))
(column-number-mode t)
(global-font-lock-mode t)

;; Display date and time in mode line
(setq display-time-format "%Y-%m-%d %H:%M")
(display-time-mode 1)

;; Highlight and face overrides
(set-face-background 'hl-line "darkblue")
(with-eval-after-load 'info
  (set-face-attribute 'info-index-match nil :background "darkslateblue"))
(with-eval-after-load 'pulse
  (set-face-attribute 'pulse-highlight-face nil :background "darkslateblue")
  (set-face-attribute 'pulse-highlight-start-face nil :background "darkslateblue"))
(with-eval-after-load 'xref
  (set-face-attribute 'xref-match nil :background "darkslateblue"))

;; ==========================================
;; 7. NAVIGATION & EDITING UTILITIES
;; ==========================================

;; Revert all buffers utility
(defun revert-all-buffers ()
  "Refresh all open buffers from their respective files."
  (interactive)
  (dolist (buf (buffer-list))
    (with-current-buffer buf
      (when (and (buffer-file-name) (not (buffer-modified-p)))
        (revert-buffer t t t))))
  (message "All non-modified buffers reverted."))
(global-set-key (kbd "C-c R") 'revert-all-buffers)

;; Smex (M-x enhancements)
(use-package smex
  :ensure t
  :init
  (setq smex-save-file (concat user-emacs-directory ".smex-items"))
  :config
  (smex-initialize)
  :bind
  (("M-x" . smex)
   ("M-X" . smex-major-mode-commands)))

;; Multiple Cursors
(use-package multiple-cursors
  :ensure t)

;; Persistent Scratch
(use-package persistent-scratch
  :ensure t
  :config
  (persistent-scratch-setup-default))

;; Interactive Do (ido)
(use-package ido
  :init
  (ido-mode 1)
  :config
  (setq ido-enable-flex-matching t
        ido-everywhere t
        ido-use-virtual-buffers t
        ido-ignore-extensions '(".o" ".pyc" "~")))

;; Ranger File Manager
(use-package ranger
  :ensure t
  :bind
  ("C-c r" . ranger)
  :config
  (setq ranger-show-hidden-files t)
  (setq-default ranger-image-preview-mode t))

;; Screensaver / Zone
(use-package zone
  :config
  (zone-when-idle 600))

;; ==========================================
;; 8. DEVELOPMENT LANGUAGES & ORG MODE
;; ==========================================

;; SLIME (Common Lisp)
(use-package slime
  :ensure t
  :init
  (setq inferior-lisp-program "sbcl"))

;; Rainbow Delimiters
(use-package rainbow-delimiters
  :ensure t
  :hook (prog-mode . rainbow-delimiters-mode))

;; Accurate syntax tree (tree-sitter)
(use-package treesit-auto
  :ensure t
  :init
  (setq treesit-language-source-alist
        '((c "https://github.com/tree-sitter/tree-sitter-c" "v0.21.4")
          (cpp "https://github.com/tree-sitter/tree-sitter-cpp" "v0.20.5")
          (python "https://github.com/tree-sitter/tree-sitter-python" "v0.21.0")
          (rust "https://github.com/tree-sitter/tree-sitter-rust" "v0.21.2")
          (go "https://github.com/tree-sitter/tree-sitter-go" "v0.21.2")
          (javascript "https://github.com/tree-sitter/tree-sitter-javascript" "v0.21.4")
          (typescript "https://github.com/tree-sitter/tree-sitter-typescript" "v0.21.2" "typescript/src")
          (tsx "https://github.com/tree-sitter/tree-sitter-typescript" "v0.21.2" "tsx/src")
          (html "https://github.com/tree-sitter/tree-sitter-html" "v0.20.3")
          (css "https://github.com/tree-sitter/tree-sitter-css" "v0.21.0")
          (json "https://github.com/tree-sitter/tree-sitter-json" "v0.21.0")
          (yaml "https://github.com/tree-sitter-grammars/tree-sitter-yaml" "v0.6.1")
          (toml "https://github.com/tree-sitter/tree-sitter-toml" "v0.5.1")
          (clojure "https://github.com/sogaiu/tree-sitter-clojure" "v0.0.13")
          (bash "https://github.com/tree-sitter/tree-sitter-bash" "v0.21.0")
          (scheme "https://github.com/6cdh/tree-sitter-scheme")
          (java "https://github.com/tree-sitter/tree-sitter-java")
          (sql "https://github.com/m-novikov/tree-sitter-sql")
          (haskell "https://github.com/tree-sitter/tree-sitter-haskell")
          (commonlisp "https://github.com/tree-sitter-grammars/tree-sitter-commonlisp")
          (ruby "https://github.com/tree-sitter/tree-sitter-ruby")
          (ocaml "https://github.com/tree-sitter/tree-sitter-ocaml" "v0.20.4" "ocaml/src")
          (erlang "https://github.com/WhatsApp/tree-sitter-erlang" "0.15")
          (swift "https://github.com/alex-pinkus/tree-sitter-swift" "0.5.0-with-generated-files")
          (kotlin "https://github.com/fwcd/tree-sitter-kotlin")
          (powershell "https://github.com/airbus-cert/tree-sitter-powershell" "v0.1.0")
          (elixir "https://github.com/elixir-lang/tree-sitter-elixir")
          (fsharp "https://github.com/ionide/tree-sitter-fsharp" "v0.1.0" "fsharp/src")
          (elm "https://github.com/elm-tooling/tree-sitter-elm" "v3.0.0")
          (php "https://github.com/tree-sitter/tree-sitter-php" "v0.21.1" "php/src")
          (markdown "https://github.com/tree-sitter-grammars/tree-sitter-markdown" "v0.2.0" "tree-sitter-markdown/src")
          (markdown-inline "https://github.com/tree-sitter-grammars/tree-sitter-markdown" "v0.2.0" "tree-sitter-markdown-inline/src")))
  :config
  (treesit-auto-add-to-auto-mode-alist 'all))

;; Org-Babel Extension Packages (ensure they are installed for third-party languages)
(use-package ob-typescript :ensure t :defer t)
(use-package ob-go :ensure t :defer t)
(use-package ob-rust :ensure t :defer t)
(use-package ob-swift :ensure t :defer t)
(use-package ob-kotlin :ensure t :defer t)
(use-package ob-powershell :ensure t :defer t)
(use-package ob-elixir :ensure t :defer t)
(use-package ob-fsharp :ensure t :defer t)
(use-package ob-elm :ensure t :defer t)
(use-package ob-php :ensure t :defer t)
(use-package ob-erlang
  :vc (:url "https://github.com/xfwduke/ob-erlang")
  :defer t)

;; Org mode Babel environments & LaTeX Setup
(with-eval-after-load 'org
  ;; Use dvisvgm to generate crisp SVG previews of LaTeX formulas
  (setq org-preview-latex-default-process 'dvisvgm)
  ;; Configure PDF compilation to use latexmk
  (setq org-latex-pdf-process
        '("latexmk -f -pdf -interaction=nonstopmode -output-directory=%o %f"))
  
  ;; Configure languages for Org-Babel evaluation
  (org-babel-do-load-languages
   'org-babel-load-languages
   '((scheme . t)
     (C . t)
     (python . t)
     (shell . t)
     (js . t)
     (java . t)
     (sql . t)
     (haskell . t)
     (clojure . t)
     (lisp . t)
     (ruby . t)
     (ocaml . t)
     (erlang . t)
     (typescript . t)
     (go . t)
     (rust . t)
     (swift . t)
     (kotlin . t)
     (powershell . t)
     (elixir . t)
     (fsharp . t)
     (elm . t)
     (php . t)))
  
  ;; Scheme settings
  (setq org-babel-scheme-interpreter "mit-scheme"
        org-babel-scheme-cmd "mit-scheme")
  
  ;; Python settings
  (setq org-babel-python-command "python3")
  
  ;; General Babel settings
  (setq org-confirm-babel-evaluate nil))

;; Geiser Scheme integration
(use-package geiser
  :ensure t
  :config
  (defun my/geiser-set-repl-directory ()
    "Set Geiser's working directory to the current file's directory."
    (when buffer-file-name
      (setq geiser-repl-working-directory (file-name-directory buffer-file-name))))
  (add-hook 'geiser-mode-hook #'my/geiser-set-repl-directory))

;; Table of Contents in Org files
(use-package toc-org
  :ensure t
  :after org
  :hook (org-mode . toc-org-mode))

;; Elfeed RSS Feed Reader
(use-package elfeed
  :ensure t
  :config
  (setq elfeed-feeds
        '(;; Aggregators & Official
          ("http://planet.clojure.in/rss20.xml" clojure community)
          ("https://clojure.org/news/feed.xml" clojure official)
          ("https://www.reddit.com/r/clojure/.rss" clojure reddit)
          ;; Companies
          ("https://www.juxt.pro/blog/rss.xml" clojure tech)
          ("https://blog.cognitect.com/blog?format=rss" clojure tech)
          ("https://freshcodeit.com/rss.xml" clojure tech)
          ;; Individuals
          ("https://www.braveclojure.com/feed.xml" clojure blog)
          ("https://borkdude.github.io/index.xml" clojure blog)
          ("https://ericnormand.me/feed" clojure blog)))
  (setq elfeed-db-max-age (* 5 24 60 60)))

;; Lisp interaction evaluation hotkey
(define-key lisp-interaction-mode-map (kbd "C-j") 'eval-print-last-sexp)

;; ==========================================
;; 9. GPTEL (AI ASSISTANT INTEGRATION)
;; ==========================================

(use-package gptel
  :ensure t
  :bind (("C-c g m" . gptel-menu)
         ("C-c g s" . gptel-send)
         ("C-c g a" . gptel-add)
         ("C-c g i" . gptel-context-inspect)
         ("C-c g c" . gptel-context-clear)
         ("C-c g b" . gptel-abort)
         ("C-c g r" . gptel-rewrite))
  :config
  ;; Retrieve the Gemini API key securely from 'pass'
  (defun my/get-gemini-key-from-pass ()
    "Retrieve the Gemini API key securely from the pass password manager."
    (if (executable-find "pass")
        (let ((key (shell-command-to-string "pass show GEMINI_API_KEY")))
          (if (string-empty-p key)
              (progn (message "Warning: 'pass show GEMINI_API_KEY' returned empty.") nil)
            (string-trim-right key)))
      (message "Error: 'pass' executable not found on this system.")
      nil))

  ;; Define Ollama backend — tuned for creativity (balanced)
  (gptel-make-ollama "Ollama"
    :host "localhost:11434"
    :models '("hermes3:3b" "qwen2.5-coder:3b")
    :stream t
    :request-params '(:options (:temperature 0.9
                                :top_p 0.95
                                :top_k 40
                                :repeat_penalty 1.1
                                :repeat_last_n 64)))

  ;; Set Ollama as default fallback — Hermes for creativity
  (setq gptel-backend (gptel-get-backend "Ollama")
        gptel-model "hermes3:3b"
        gptel-temperature 0.9)

  (let ((secret-key (my/get-gemini-key-from-pass)))
    (when secret-key
      ;; Create the Gemini backend object
      (let ((gemini-backend (gptel-make-gemini "Gemini"
                              :key secret-key
                              :stream t
                              :models '(gemini-3.7-flash gemini-3.6-flash gemini-3.5-flash gemini-3.5-flash-lite gemini-3.1-pro-preview))))
        ;; Set Gemini as the default system-wide backend and preferred model
        (setq gptel-backend gemini-backend
              gptel-model 'gemini-3.5-flash-lite))))

  ;; Set pass store time 
  (setenv "PASSWORD_STORE_CLIP_TIME" "3600")

  (setq gptel-directives
        '((default . "You are a large language model living in Emacs and a helpful assistant. Respond concisely. Always talk in ASD-STE100 Simplified Technical English. Always talk to me like I have ADHD.")
          (coder   . "You are an expert programmer. Write clean, concise code.")))

  ;; Update the system message since gptel--system-message is a defvar and won't automatically update from gptel-directives configuration set in :config
  (setq gptel--system-message (alist-get 'default gptel-directives)))


(global-set-key (kbd "C-j") 'eval-print-last-sexp)
(evil-mode 0)


