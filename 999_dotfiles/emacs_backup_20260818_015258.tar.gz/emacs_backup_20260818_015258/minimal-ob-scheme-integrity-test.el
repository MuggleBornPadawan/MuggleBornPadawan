;; ~/minimal-ob-scheme-integrity-test.el
(message "Starting minimal ob-scheme integrity test...")
(require 'org) ;; For Org version, and basic Org environment
(message "Org version: %s" (org-version))

(message "Requiring 'ob-scheme'...")
(condition-case err
    (progn
      (require 'ob-scheme)
      (message "'ob-scheme' required successfully."))
  (error (message "Error requiring 'ob-scheme': %S" err)
         ;; If ob-scheme fails to load, the test below is moot.
         (setq ob-scheme-load-failed t)))

(message "--- Directly checking 'org-babel-scheme-backend' state ---")
(if (and (not (bound-and-true-p ob-scheme-load-failed))
         (fboundp 'org-babel-scheme-backend))
    (condition-case err
        (let ((backend-result (org-babel-scheme-backend nil))) ;; Pass nil for params
          (message "Call to (org-babel-scheme-backend nil) immediately after require returned: %S" backend-result))
      (error (message "Call to (org-babel-scheme-backend nil) immediately after require ERRORED: %S" err)))
  (if (bound-and-true-p ob-scheme-load-failed)
      (message "'ob-scheme' failed to load, check skipped.")
    (message "'org-babel-scheme-backend' is NOT fboundp immediately after require.")))
(message "--- End of integrity test ---")
