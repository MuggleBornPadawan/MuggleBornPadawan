;; ~/minimal-emacs-test.el (Revised May 20, 2025 - Deeper Geiser Diag)

(message "Starting minimal-emacs-test.el (Deeper Geiser Diag)...")

;; 1. Load Org mode core
(require 'org)
(message "Org loaded. Org version: %s" (org-version))

;; 2. Explicitly require the babel library for scheme.
(condition-case err
    (progn
      (require 'ob-scheme)
      (message "ob-scheme explicitly required successfully."))
  (error (message "Error requiring ob-scheme: %S" err)))

;; 3. Activate Scheme language support in Org Babel.
(org-babel-do-load-languages
 'org-babel-load-languages
 '((scheme . t)))
(message "org-babel-do-load-languages called for 'scheme symbol.")

;; 4. Standard Diagnostic Checks:
(if (assoc 'scheme org-babel-load-languages)
    (message "Standard Diag: (symbol) 'scheme' IS present in org-babel-load-languages. This is good.")
  (message "Standard Diag: (symbol) 'scheme' is NOT in org-babel-load-languages. Value: %S" org-babel-load-languages))

(if (fboundp 'org-babel-execute:scheme)
    (message "Standard Diag: org-babel-execute:scheme IS defined (fboundp). This is good!")
  (message "Standard Diag: org-babel-execute:scheme is NOT defined."))

;; 5. DEEPER GEISER DIAGNOSTICS (before setting interpreter, after ob-scheme is loaded)
(message "--- Deeper Geiser Diagnostics Start ---")
(message "Geiser Diag: (featurep 'geiser-repl) -> %S" (featurep 'geiser-repl))
(message "Geiser Diag: (fboundp 'geiser-eval-region) -> %S" (fboundp 'geiser-eval-region))
(message "Geiser Diag: (fboundp 'geiser-repl-current-type) -> %S" (fboundp 'geiser-repl-current-type))

(if (fboundp 'geiser-repl-current-type)
    (condition-case err
        (let ((geiser-type (geiser-repl-current-type)))
          (message "Geiser Diag: call to (geiser-repl-current-type) succeeded. Value -> %S" geiser-type))
      (error (message "Geiser Diag: call to (geiser-repl-current-type) ERRORED: %S" err)))
  (message "Geiser Diag: (geiser-repl-current-type) is not fboundp, so not called."))

;; Check what backend ob-scheme itself would choose:
;; The 'org-babel-scheme-backend' function is defined in ob-scheme.el
(if (fboundp 'org-babel-scheme-backend)
    (condition-case err
        (let ((chosen-backend (org-babel-scheme-backend nil))) ;; nil for params
           (message "Geiser Diag: (org-babel-scheme-backend nil) -> %S" chosen-backend))
      (error (message "Geiser Diag: call to (org-babel-scheme-backend nil) ERRORED: %S" err)))
  (message "Geiser Diag: org-babel-scheme-backend is not fboundp (should not happen if ob-scheme loaded)."))
(message "--- Deeper Geiser Diagnostics End ---")

;; 6. Set the Scheme interpreter
(setq org-babel-scheme-interpreter "mit-scheme")
(message "Minimal config fully loaded. Scheme interpreter intended to be: %s" org-babel-scheme-interpreter)
(message "---------------------------------------------------------------------")
(message "NOW: Create a new .org file, type a clean Scheme block, and try C-c C-c.")
